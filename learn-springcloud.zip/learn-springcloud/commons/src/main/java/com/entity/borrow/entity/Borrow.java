package com.entity.borrow.entity;

import lombok.Data;

@Data
public class Borrow {
    Long id;
    Integer uid;
    Integer bid;
}
