package com.entity.user.entity;

import lombok.Data;

@Data
public class User {
    Long uid;
    String name;
    Integer age;
    String sex;
}
