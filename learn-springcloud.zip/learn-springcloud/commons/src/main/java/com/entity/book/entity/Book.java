package com.entity.book.entity;

import lombok.Data;

@Data
public class Book {
    Long bid;
    String title;
    String desc;
}
